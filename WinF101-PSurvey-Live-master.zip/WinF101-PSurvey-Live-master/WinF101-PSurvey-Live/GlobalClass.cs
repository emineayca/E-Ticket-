﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinF101_PSurvey_Live
{
    public class GlobalClass
    {
        public static int UserID; // her yerde kullanabilirim.Static tanımlandığı için bu değişgene ulaşabilmek için direk classın propertysine ulaşabilir.

        public static int QID;



    }
}
